# Introduction
Student Name:  Sheikh Muhammad Adib Bin Sh Abu bakar 

Student ID:    7219310

Course of study: ESE

### Directory tree
* [Main](https://github.com/sheikh-adib/JAVA-Course/tree/main)
  * [Java Hometasks/](https://github.com/sheikh-adib/JAVA-Course/tree/main/Java%20Hometasks)
      * Homework assignment 1/
        * [Problem 1/](./Problem_1)
        * [Problem 2/](./Problem_2)
        * [Problem 3/](./Problem_3)
        * [Problem 4/](./Problem_4)
      * [Homework assignment 2/](https://github.com/sheikh-adib/JAVA-Course/tree/main/Java%20Hometasks/Homework_assignment_2)
      * [Homework assignment 3/](https://github.com/sheikh-adib/JAVA-Course/tree/main/Java%20Hometasks/Homework_assignment_3)
   
### Enviroment
- Language: JAVA
- using openJDK-20
- IDE: IntelliJ   

# Homework Assignment 1
## Problem 1
1. Number of solution file: 1
2. Folder: [Problem_1](./Problem_1)
3. README: [README file](./Problem_1/README.md)
4. Main file: [MathCalc.java](./Problem_1/src/MathCalc.java)


## Problem 2
1. Number of solution file: 1
2. Folder: [Problem_2](./Problem_2)
3. README: [README file](./Problem_2/README.md)
4. Main file: [Primes.java](./Problem_2/src/Primes.java)


## Problem 3
1. Number of solution file: 1
2. Folder: [Problem_3](./Problem_3)
3. README: [README file](./Problem_3/README.md)
4. Main file: [StringCharacters.java](./Problem_3/src/StringCharacters.java)

## Problem 4
1. Number of solution file: 1
2. Folder: [Problem_4](./Problem_4)
3. README: [README file](./Problem_4/README.md)
4. Main file: [Main.java](./Problem_4/src/Main.java)
