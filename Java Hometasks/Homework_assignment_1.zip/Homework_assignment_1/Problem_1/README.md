# Student Information

Fachhochschule Dortmund

Sheikh Muhammad Adib Bin Sheikh Abu Bakar

Student ID: 7219310

ESE student

# Task
Task: Homework assignment 1/Problem 1

# Development enviroment
- Language: JAVA
- using openJDK-20
- IDE: IntelliJ

# Solution
Number of file: 1

main file: [MathCalc.java](./src/MathCalc.java)

A module is created to culclate sphere volume
```java
public static double volumeCal(double r)
    {
        return (4 * Math.PI * Math.pow( r , 3.0 ) ) / 3;
    }
```

# Output
```
The volume of the Earth is 2.2984729611703882E11 cubic miles, the volume of the sun is 3.388807851993121E17 cubic miles, and the ratio of the volume of the Sun to the volume of the Earth is 1474373.5990122468.
```

